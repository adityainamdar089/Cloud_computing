import { GoogleGenerativeAI } from "@google/generative-ai";
import { createError } from "../error.js";

const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "AIzaSyDGIz0JX-ma0YqBfJzl3t59dnBYoxj0ZOk";

export const generateContent = async (req, res, next) => {
  try {
    console.log('Gemini generateContent called');
    console.log('Request body:', JSON.stringify(req.body));
    
    // Validate request body exists
    if (!req.body || typeof req.body !== 'object') {
      res.setHeader('access-control-allow-origin', '*');
      res.setHeader('access-control-allow-headers', 'Content-Type,Authorization,X-Requested-With,Accept');
      res.setHeader('access-control-allow-methods', 'GET,POST,PUT,DELETE,OPTIONS,PATCH');
      return next(createError(400, "Request body is required and must be a JSON object"));
    }
    
    const { prompt, model = "gemini-2.5-flash", maxOutputTokens = 1200 } = req.body;
    
    console.log('Extracted prompt:', prompt ? 'present' : 'missing');
    console.log('Model requested:', model);
    console.log('Max output tokens:', maxOutputTokens);

    if (!prompt) {
      // HTTP API Gateway v2 requires lowercase header names
      res.setHeader('access-control-allow-origin', '*');
      res.setHeader('access-control-allow-headers', 'Content-Type,Authorization,X-Requested-With,Accept');
      res.setHeader('access-control-allow-methods', 'GET,POST,PUT,DELETE,OPTIONS,PATCH');
      return next(createError(400, "Prompt is required"));
    }

    if (!GEMINI_API_KEY) {
      // HTTP API Gateway v2 requires lowercase header names
      res.setHeader('access-control-allow-origin', '*');
      res.setHeader('access-control-allow-headers', 'Content-Type,Authorization,X-Requested-With,Accept');
      res.setHeader('access-control-allow-methods', 'GET,POST,PUT,DELETE,OPTIONS,PATCH');
      return next(
        createError(
          500,
          "Gemini API key is not configured. Please set GEMINI_API_KEY or REACT_APP_GEMINI_API_KEY environment variable."
        )
      );
    }

    // Try multiple models in order - using only Gemini 2.5 series
    // Primary: gemini-2.5-flash (fast, cost-effective)
    // Fallback: gemini-2.5-pro (more capable)
    const modelsToTry = ["gemini-2.5-flash", "gemini-2.5-pro"];
    const modelToUse = modelsToTry.includes(model) ? model : modelsToTry[0];

    let lastError = null;
    let genAI = null;
    let selectedModel = null;

    // Helper function to retry with exponential backoff
    const retryWithBackoff = async (fn, maxRetries = 3, baseDelay = 1000) => {
      for (let attempt = 0; attempt < maxRetries; attempt++) {
        try {
          return await fn();
        } catch (err) {
          const errorMessage = err.message || err.toString();
          const isOverloaded = errorMessage.includes("503") || 
                              errorMessage.includes("overloaded") || 
                              errorMessage.includes("Service Unavailable");
          
          // Don't retry on quota/rate limit errors (429) - try next model instead
          const isQuotaExceeded = errorMessage.includes("429") ||
                                  errorMessage.includes("quota exceeded") ||
                                  errorMessage.includes("too many requests");
          
          if (isQuotaExceeded) {
            console.log(`Quota exceeded, will try next model instead of retrying`);
            throw err; // Let outer loop handle trying next model
          }
          
          if (isOverloaded && attempt < maxRetries - 1) {
            // Exponential backoff: 1s, 2s, 4s
            const delay = baseDelay * Math.pow(2, attempt);
            console.log(`Model overloaded, retrying in ${delay}ms (attempt ${attempt + 1}/${maxRetries})...`);
            await new Promise(resolve => setTimeout(resolve, delay));
            continue;
          }
          throw err;
        }
      }
    };

    // Try each model until one works
    for (const modelName of modelsToTry) {
      try {
        console.log(`Attempting to use model: ${modelName}`);
        genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
        selectedModel = genAI.getGenerativeModel({ model: modelName });
        
        console.log(`Model ${modelName} initialized, generating content...`);
        
        // Retry with backoff for overloaded errors
        const result = await retryWithBackoff(async () => {
          return await selectedModel.generateContent(prompt);
        });
        
        console.log(`Model ${modelName} generated content successfully`);
        
        // Safely extract response text
        let text = '';
        try {
          const response = await result.response;
          text = response.text();
          
          if (!text || typeof text !== 'string') {
            throw new Error('Invalid response format: text is not a string');
          }
        } catch (textError) {
          console.error(`Error extracting text from response:`, textError);
          throw new Error(`Failed to extract text from response: ${textError.message}`);
        }

        if (text && text.trim().length > 0) {
          console.log(`Successfully generated ${text.length} characters of text`);
          return res.status(200).json({
            success: true,
            text: text.trim(),
            model: modelName,
          });
        } else {
          throw new Error('Generated text is empty');
        }
      } catch (err) {
        lastError = err;
        const errorMessage = err.message || err.toString() || String(err);
        const errorString = errorMessage.toLowerCase();
        
        console.error(`Error with model ${modelName}:`, errorMessage);
        console.error('Error type:', err.constructor?.name || typeof err);
        console.error('Error code:', err.code);
        console.error('Full error object:', JSON.stringify(err, Object.getOwnPropertyNames(err)));
        
        // If it's a 404 (model not found), try next model
        if (errorString.includes("404") || 
            errorString.includes("not found") || 
            errorString.includes("model not found") ||
            errorString.includes("invalid model") ||
            errorString.includes("model name")) {
          console.log(`Model ${modelName} not found or invalid, trying next model...`);
          continue;
        }
        
        // If it's overloaded or quota exceeded, try next model if available
        if (errorString.includes("503") || 
            errorString.includes("overloaded") || 
            errorString.includes("service unavailable") ||
            errorString.includes("429") ||
            errorString.includes("too many requests") ||
            errorString.includes("quota") ||
            errorString.includes("rate limit") ||
            errorString.includes("quota exceeded")) {
          if (modelsToTry.indexOf(modelName) < modelsToTry.length - 1) {
            console.log(`Model ${modelName} overloaded, rate limited, or quota exceeded, trying next model...`);
            continue;
          }
        }
        
        // If it's an authentication error, don't try other models
        if (errorString.includes("401") || 
            errorString.includes("unauthorized") || 
            errorString.includes("api key") ||
            errorString.includes("authentication") ||
            errorString.includes("permission denied")) {
          console.error(`Authentication error with model ${modelName}, stopping all attempts`);
          break;
        }
        
        // For other errors, try next model if available, otherwise break
        if (modelsToTry.indexOf(modelName) < modelsToTry.length - 1) {
          console.log(`Error with model ${modelName}, trying next model...`);
          continue;
        } else {
          console.error(`Fatal error with model ${modelName} (last model), stopping retries:`, errorMessage);
          break;
        }
      }
    }

    // If we get here, all models failed
    const errorMessage = lastError?.message || lastError?.toString() || "Failed to generate content from Gemini API";
    const errorString = errorMessage.toLowerCase();
    const isOverloaded = errorString.includes("503") || 
                        errorString.includes("overloaded") || 
                        errorString.includes("service unavailable");
    const isQuotaExceeded = errorString.includes("429") ||
                           errorString.includes("quota exceeded") ||
                           errorString.includes("too many requests");

    // Provide user-friendly error message
    let userMessage = errorMessage;
    if (isQuotaExceeded) {
      userMessage = `Gemini API quota exceeded. Please check your API quota and billing. Tried models: ${modelsToTry.join(", ")}. Please wait before retrying or upgrade your plan.`;
    } else if (isOverloaded) {
      userMessage = `Gemini API models are currently overloaded. Please try again in a few moments. All models were tried: ${modelsToTry.join(", ")}`;
    } else {
      userMessage = `Gemini API error: ${errorMessage}. Tried models: ${modelsToTry.join(", ")}`;
    }

    // Set CORS headers before sending error (lowercase for HTTP API Gateway v2)
    res.setHeader('access-control-allow-origin', '*');
    res.setHeader('access-control-allow-headers', 'Content-Type,Authorization,X-Requested-With,Accept');
    res.setHeader('access-control-allow-methods', 'GET,POST,PUT,DELETE,OPTIONS,PATCH');
    res.setHeader('access-control-allow-credentials', 'true');
    
    return next(
      createError(
        503,
        userMessage
      )
    );
  } catch (err) {
    console.error('Unexpected error in generateContent:', err);
    console.error('Error stack:', err.stack);
    console.error('Error name:', err.name);
    console.error('Error message:', err.message);
    
    // Set CORS headers before sending error (lowercase for HTTP API Gateway v2)
    res.setHeader('access-control-allow-origin', '*');
    res.setHeader('access-control-allow-headers', 'Content-Type,Authorization,X-Requested-With,Accept');
    res.setHeader('access-control-allow-methods', 'GET,POST,PUT,DELETE,OPTIONS,PATCH');
    res.setHeader('access-control-allow-credentials', 'true');
    
    const errorMessage = err.message || err.toString() || "Internal server error";
    console.error('Returning error to client:', errorMessage);
    
    return next(createError(500, `Internal server error: ${errorMessage}`));
  }
};

